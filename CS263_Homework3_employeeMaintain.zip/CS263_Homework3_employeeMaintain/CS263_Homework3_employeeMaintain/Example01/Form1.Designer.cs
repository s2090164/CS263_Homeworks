﻿namespace Example01
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEmployeeId = new System.Windows.Forms.Label();
            this.txtEmployeeId = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.txtBaseSalary = new System.Windows.Forms.TextBox();
            this.lblBaseSalary = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.richTxtEmployee = new System.Windows.Forms.RichTextBox();
            this.lblEmployeeType = new System.Windows.Forms.Label();
            this.comBoxEmployeeType = new System.Windows.Forms.ComboBox();
            this.lblPerformance = new System.Windows.Forms.Label();
            this.txtPerformance = new System.Windows.Forms.TextBox();
            this.lblGroupPerformance = new System.Windows.Forms.Label();
            this.comboBoxGroupPerformance = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblEmployeeId
            // 
            this.lblEmployeeId.AutoSize = true;
            this.lblEmployeeId.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployeeId.Location = new System.Drawing.Point(35, 60);
            this.lblEmployeeId.Name = "lblEmployeeId";
            this.lblEmployeeId.Size = new System.Drawing.Size(111, 31);
            this.lblEmployeeId.TabIndex = 0;
            this.lblEmployeeId.Text = "員工ID：";
            // 
            // txtEmployeeId
            // 
            this.txtEmployeeId.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtEmployeeId.Location = new System.Drawing.Point(159, 58);
            this.txtEmployeeId.Name = "txtEmployeeId";
            this.txtEmployeeId.Size = new System.Drawing.Size(154, 35);
            this.txtEmployeeId.TabIndex = 1;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtEmployeeName.Location = new System.Drawing.Point(159, 106);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(154, 35);
            this.txtEmployeeName.TabIndex = 3;
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployeeName.Location = new System.Drawing.Point(30, 108);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(134, 31);
            this.lblEmployeeName.TabIndex = 2;
            this.lblEmployeeName.Text = "員工姓名：";
            // 
            // txtBaseSalary
            // 
            this.txtBaseSalary.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBaseSalary.Location = new System.Drawing.Point(478, 106);
            this.txtBaseSalary.Name = "txtBaseSalary";
            this.txtBaseSalary.Size = new System.Drawing.Size(154, 35);
            this.txtBaseSalary.TabIndex = 5;
            // 
            // lblBaseSalary
            // 
            this.lblBaseSalary.AutoSize = true;
            this.lblBaseSalary.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblBaseSalary.Location = new System.Drawing.Point(349, 108);
            this.lblBaseSalary.Name = "lblBaseSalary";
            this.lblBaseSalary.Size = new System.Drawing.Size(134, 31);
            this.lblBaseSalary.TabIndex = 4;
            this.lblBaseSalary.Text = "員工底薪：";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnAdd.Location = new System.Drawing.Point(766, 156);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(154, 45);
            this.btnAdd.TabIndex = 6;
            this.btnAdd.Text = "新增員工";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // richTxtEmployee
            // 
            this.richTxtEmployee.Location = new System.Drawing.Point(18, 222);
            this.richTxtEmployee.Name = "richTxtEmployee";
            this.richTxtEmployee.Size = new System.Drawing.Size(902, 159);
            this.richTxtEmployee.TabIndex = 7;
            this.richTxtEmployee.Text = "";
            // 
            // lblEmployeeType
            // 
            this.lblEmployeeType.AutoSize = true;
            this.lblEmployeeType.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployeeType.Location = new System.Drawing.Point(12, 14);
            this.lblEmployeeType.Name = "lblEmployeeType";
            this.lblEmployeeType.Size = new System.Drawing.Size(134, 31);
            this.lblEmployeeType.TabIndex = 8;
            this.lblEmployeeType.Text = "員工身分：";
            // 
            // comBoxEmployeeType
            // 
            this.comBoxEmployeeType.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comBoxEmployeeType.FormattingEnabled = true;
            this.comBoxEmployeeType.Items.AddRange(new object[] {
            "一般員工",
            "業務",
            "主管"});
            this.comBoxEmployeeType.Location = new System.Drawing.Point(153, 14);
            this.comBoxEmployeeType.Name = "comBoxEmployeeType";
            this.comBoxEmployeeType.Size = new System.Drawing.Size(160, 31);
            this.comBoxEmployeeType.TabIndex = 9;
            this.comBoxEmployeeType.SelectedIndexChanged += new System.EventHandler(this.comBoxEmployeeType_SelectedIndexChanged);
            // 
            // lblPerformance
            // 
            this.lblPerformance.AutoSize = true;
            this.lblPerformance.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblPerformance.Location = new System.Drawing.Point(688, 108);
            this.lblPerformance.Name = "lblPerformance";
            this.lblPerformance.Size = new System.Drawing.Size(86, 31);
            this.lblPerformance.TabIndex = 10;
            this.lblPerformance.Text = "業績：";
            // 
            // txtPerformance
            // 
            this.txtPerformance.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPerformance.Location = new System.Drawing.Point(766, 106);
            this.txtPerformance.Name = "txtPerformance";
            this.txtPerformance.Size = new System.Drawing.Size(154, 35);
            this.txtPerformance.TabIndex = 11;
            // 
            // lblGroupPerformance
            // 
            this.lblGroupPerformance.AutoSize = true;
            this.lblGroupPerformance.Font = new System.Drawing.Font("微軟正黑體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblGroupPerformance.Location = new System.Drawing.Point(30, 156);
            this.lblGroupPerformance.Name = "lblGroupPerformance";
            this.lblGroupPerformance.Size = new System.Drawing.Size(134, 31);
            this.lblGroupPerformance.TabIndex = 12;
            this.lblGroupPerformance.Text = "團隊績效：";
            // 
            // comboBoxGroupPerformance
            // 
            this.comboBoxGroupPerformance.Font = new System.Drawing.Font("新細明體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBoxGroupPerformance.FormattingEnabled = true;
            this.comboBoxGroupPerformance.Items.AddRange(new object[] {
            "A+",
            "B+",
            "C+",
            "D"});
            this.comboBoxGroupPerformance.Location = new System.Drawing.Point(159, 156);
            this.comboBoxGroupPerformance.Name = "comboBoxGroupPerformance";
            this.comboBoxGroupPerformance.Size = new System.Drawing.Size(160, 31);
            this.comboBoxGroupPerformance.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 403);
            this.Controls.Add(this.comboBoxGroupPerformance);
            this.Controls.Add(this.lblGroupPerformance);
            this.Controls.Add(this.txtPerformance);
            this.Controls.Add(this.lblPerformance);
            this.Controls.Add(this.comBoxEmployeeType);
            this.Controls.Add(this.lblEmployeeType);
            this.Controls.Add(this.richTxtEmployee);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtBaseSalary);
            this.Controls.Add(this.lblBaseSalary);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.lblEmployeeName);
            this.Controls.Add(this.txtEmployeeId);
            this.Controls.Add(this.lblEmployeeId);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmployeeId;
        private System.Windows.Forms.TextBox txtEmployeeId;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.TextBox txtBaseSalary;
        private System.Windows.Forms.Label lblBaseSalary;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.RichTextBox richTxtEmployee;
        private System.Windows.Forms.Label lblEmployeeType;
        private System.Windows.Forms.ComboBox comBoxEmployeeType;
        private System.Windows.Forms.Label lblPerformance;
        private System.Windows.Forms.TextBox txtPerformance;
        private System.Windows.Forms.Label lblGroupPerformance;
        private System.Windows.Forms.ComboBox comboBoxGroupPerformance;
    }
}

