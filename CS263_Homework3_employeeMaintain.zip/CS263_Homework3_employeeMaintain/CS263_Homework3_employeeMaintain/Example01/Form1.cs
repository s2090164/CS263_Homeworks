﻿using Lib.DataLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example01
{
    public partial class Form1 : Form
    {
        private List<EmployeeLib> employees;

        public Form1()
        {
            InitializeComponent();
            employees = new List<EmployeeLib>();
            lblPerformance.Visible = txtPerformance.Visible = false;
            lblGroupPerformance.Visible = comboBoxGroupPerformance.Visible = false;
        }

        /// <summary>
        /// 新增員工 Add Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            EmployeeLib employee = null;

            //依據 ComboBox 的選擇不同，而使用不同的Lib
            switch (comBoxEmployeeType.SelectedIndex)
            {
                //一般員工
                case 0:
                    employee = new EmployeeLib(txtEmployeeId.Text, txtEmployeeName.Text, txtBaseSalary.Text);
                    break;

                //業務
                case 1:
                    employee = new SalesLib(txtEmployeeId.Text, txtEmployeeName.Text, txtBaseSalary.Text, txtPerformance.Text);
                    break;

                //主管
                case 2:
                    employee = new ManagerLib(txtEmployeeId.Text,
                        txtEmployeeName.Text, Int32.Parse(txtBaseSalary.Text),
                        comboBoxGroupPerformance.SelectedItem.ToString());
                    break;
            }

            employees.Add(employee);
            UpdateEmployeeInfo();
        }

        //寫出員工資料
        private void UpdateEmployeeInfo()
        {
            richTxtEmployee.Text = string.Empty;
            txtBaseSalary.Text = txtEmployeeId.Text = txtEmployeeName.Text = txtPerformance.Text = string.Empty;
            foreach (EmployeeLib employee in employees)
            {
                richTxtEmployee.Text += string.Format("{0}", employee.ToString());
            }
        }

        private void comBoxEmployeeType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //依據 ComboBox 的選擇不同，而有不同的顯示
            switch (comBoxEmployeeType.SelectedIndex)
            {
                //一般員工
                case 0:
                    txtBaseSalary.Text = txtEmployeeId.Text = txtEmployeeName.Text = txtPerformance.Text = string.Empty;
                    lblPerformance.Visible = txtPerformance.Visible = false;
                    lblGroupPerformance.Visible = comboBoxGroupPerformance.Visible = false;
                    break;

                //業務
                case 1:
                    lblPerformance.Visible = txtPerformance.Visible = true;
                    lblGroupPerformance.Visible = comboBoxGroupPerformance.Visible = false;
                    txtBaseSalary.Text = txtEmployeeId.Text = txtEmployeeName.Text = txtPerformance.Text = string.Empty;
                    break;

                //主管
                case 2:
                    lblPerformance.Visible = txtPerformance.Visible = false;
                    lblGroupPerformance.Visible = comboBoxGroupPerformance.Visible = true;
                    txtBaseSalary.Text = txtEmployeeId.Text = txtEmployeeName.Text = txtPerformance.Text = string.Empty;
                    break;
            }
        }
    }
}