﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.DataLib
{
    public class SalesLib : EmployeeLib
    {
        private int performance;

        public int Performance
        {
            get { return this.performance; }
            set
            {
                // 如果業績 <0，則業績為 0
                if (value < 0)
                    this.performance = 0;
                else
                    this.performance = value;
            }
        }

        public SalesLib(string employeeId, string employeeName, string basesalary, string performance)
            : this(employeeId, employeeName, int.Parse(basesalary), int.Parse(performance))
        {
        }

        public SalesLib(string employeeId, string employeeName, int basesalary, int performance)
            : base(employeeId, employeeName, basesalary)
        {
            this.Performance = performance;
        }

        public override string ToString()
        {
            return base.ToString() + string.Format("業績：{0}\n", this.Performance);
        }
    }
}