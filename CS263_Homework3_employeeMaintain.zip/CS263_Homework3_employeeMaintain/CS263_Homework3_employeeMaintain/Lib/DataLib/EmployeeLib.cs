﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.DataLib
{
    public class EmployeeLib
    {
        /// <summary>
        /// 員工ID
        /// </summary>
        public string EmployeeId { get; set; }

        /// <summary>
        /// 員工姓名
        /// </summary>
        public string EmployeeName { get; set; }

        protected int basesalary;

        /// <summary>
        /// 底薪
        /// </summary>
        virtual public int BaseSalary
        {
            get { return this.basesalary; }

            set
            {
                if (value >= 22000)
                    this.basesalary = value;
                else if (value < 22000)
                    this.basesalary = 22000;
            }
        }

        public EmployeeLib(string employeeId, string employeeName, string basesalary)
            : this(employeeId, employeeName, int.Parse(basesalary))
        {
        }

        public EmployeeLib(string employeeId, string employeeName, int basesalary)
        {
            this.EmployeeId = employeeId;
            this.EmployeeName = employeeName;
            this.BaseSalary = basesalary;
        }

        public override string ToString()
        {
            string result = string.Empty;

            result += string.Format("員工Id：{0}\n", this.EmployeeId);
            result += string.Format("員工姓名：{0}\n", this.EmployeeName);
            result += string.Format("員工底薪：{0}\n", this.BaseSalary);
            return result;
        }
    }
}