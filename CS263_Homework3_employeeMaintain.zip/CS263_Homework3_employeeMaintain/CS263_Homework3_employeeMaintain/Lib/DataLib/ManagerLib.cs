﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.DataLib
{
    public class ManagerLib : EmployeeLib
    {
        private string groupperformancelevel { get; set; }

        public string GroupPerformanceLevel { get; set; }

        public ManagerLib(string employeeId, string employeeName,
            int basesalary, string groupperformancelevel)
            : base(employeeId, employeeName, basesalary)
        {
            // 依據團隊績效不同，主管薪水 * 倍率
            switch (groupperformancelevel)
            {
                case "A+":
                    basesalary = (int)(basesalary * 1.5);
                    break;

                case "B+":
                    basesalary = (int)(basesalary * 1.35);
                    break;

                case "C+":
                    basesalary = (int)(basesalary * 1.2);
                    break;

                case "D":
                default:
                    break;
            }

            this.GroupPerformanceLevel = groupperformancelevel;
            this.BaseSalary = basesalary;
        }

        // override
        public override string ToString()
        {
            // 寫出團隊績效
            return base.ToString() + string.Format("團隊績效：{0}\n", this.GroupPerformanceLevel);
        }
    }
}