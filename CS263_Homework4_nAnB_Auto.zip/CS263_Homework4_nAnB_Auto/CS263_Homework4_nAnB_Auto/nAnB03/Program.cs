﻿using Lib.BizLib;
using Lib.DataLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nAnB03
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("遊戲開始！！");

            GameBiz gameBiz = new GameBiz();
            int intGameCount = 0;  // 遊戲猜了幾次
            int[] result = gameBiz.GetResult(true, out intGameCount);

            Console.WriteLine("遊戲結束，結果為{0}{1}{2}{3}，總共猜了{4}次", result[0], result[1], result[2], result[3], intGameCount);
            Console.ReadLine();
        }
    }
}