﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.BizLib
{
    public class GameBiz
    {
        /// <summary>
        /// Check 輸入數字是否全對且位置無誤，並 Console Write nAnB
        /// </summary>
        /// <param name="isViolence">是否使用暴力破解</param>
        /// <param name="gameCount">電腦猜了幾次</param>
        /// <returns>答案</returns>
        public int[] GetResult(bool isViolence, out int gameCount)
        {
            // 電腦猜題次數
            gameCount = 0;

            RandomBiz randomBiz = new RandomBiz();

            // 取得問題與電腦猜的答案 (Tmp)
            List<int> question = randomBiz.GenerateRandomNumber();
            List<int> answerTmp;

            // 初始 1 個長度為4，裡頭都是-1的 int Array (random 是 0-9，所以不會有 -1)
            int[] answer = new int[4] { -1, -1, -1, -1 };

            //電腦猜題可用剩餘數字
            List<int> answerTmpA = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            do
            {
                // 遊戲次數加 1
                gameCount += 1;

                // 電腦猜題
                if (isViolence)
                {
                    // 是否啟用暴力破解 (忽略剩於可用數字，一直丟亂數去破解)
                    answerTmp = randomBiz.GenerateRandomNumber();
                }
                else
                {
                    // 非暴力破解，會有剩餘數字
                    answerTmp = randomBiz.GenerateRandomNumber(answerTmpA);
                }

                for (int i = 0; i < answerTmp.Count; i++)
                {
                    // 如果 answer[i] != -1，代表之前已經猜中，否則繼續猜
                    if (answer[i] == -1)
                    {
                        if (answerTmp[i] == question[i])
                        {
                            // 如果猜對就將 answer Array 中的 -1 改為答案數字
                            answer[i] = answerTmp[i];

                            // 透過答案清除剩餘數字
                            answerTmpA.Remove(answerTmp[i]);
                        }
                    }
                    else
                    {
                    }
                }
            } while (answer.Contains(-1));  // 再也沒有 -1 ，就跳出去 do While

            return answer;
        }
    }
}