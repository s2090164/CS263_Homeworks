﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib.BizLib
{
    public class RandomBiz
    {
        /// <summary>
        /// 產生0到9的不重複亂數，將其置入到 List<int> 後 Return
        /// </summary>
        /// <returns>0到9的不重複亂數的 int List</returns>
        public List<int> GenerateRandomNumber()
        {
            List<int> result = new List<int>();

            Random rnd = new Random();

            do
            {
                //0-9的亂數結果
                int tmp = rnd.Next(0, 10);

                if (result.Count > 0)
                {
                    // 不存在才塞進 List
                    if (result.Contains(tmp) == false)
                        result.Add(tmp);
                }
                else
                    result.Add(tmp);
            } while (result.Count < 4);

            return result;
        }

        /// <summary>
        /// (輸入剩餘未被猜過的數字 List) 產生0到9的不重複亂數，將其置入到 List<int> 後 Return
        /// </summary>
        /// <param name="answerTmpA">輸入剩餘未被猜過的數字 List</param>
        /// <returns>0到9的不重複亂數的 int List</returns>
        public List<int> GenerateRandomNumber(List<int> answerTmpA)
        {
            List<int> result = new List<int>();

            Random rnd = new Random();

            // 如果剩餘未被猜過的數字多於4個以上
            if (answerTmpA.Count > 4)
            {
                // 開始進行亂數 index 的擺放 (Index 可能重複但有防呆，數字結果不重複)
                do
                {
                    int tmp = rnd.Next(0, answerTmpA.Count);

                    if (result.Count > 0)
                    {
                        if (result.Contains(tmp) == false)
                            result.Add(answerTmpA[tmp]);
                    }
                    else
                        result.Add(answerTmpA[tmp]);
                } while (result.Count < 4);
            }
            else
            {
                //否則就全部丟出來
                for (int i = 0; i < answerTmpA.Count; i++)
                {
                    result.Add(answerTmpA[i]);
                }
            }

            return result;
        }
    }
}